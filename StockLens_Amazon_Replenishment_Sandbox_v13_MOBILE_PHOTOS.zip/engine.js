
(function(){
"use strict";
const M=window.STOCKLENS_MASTER;
function num(v,d=0){ if(v===null||v===undefined)return d; let s=String(v).trim().replace(/,/g,"").replace(/\+$/,""); let n=Number(s); return Number.isFinite(n)?n:d; }
function clean(s){return String(s??"").trim();}
function packCount(sku){ const m=clean(sku).match(/^(\d+)x/i); return m?Number(m[1]):1; }
function parseCSV(text){
  const rows=[]; let row=[], cell="", q=false;
  for(let i=0;i<text.length;i++){ const ch=text[i], nx=text[i+1];
    if(q){ if(ch=='"'&&nx=='"'){cell+='"';i++;} else if(ch=='"'){q=false;} else cell+=ch; }
    else { if(ch=='"')q=true; else if(ch==','){row.push(cell);cell="";} else if(ch=='\n'){row.push(cell.replace(/\r$/,""));rows.push(row);row=[];cell="";} else cell+=ch; }
  }
  if(cell.length||row.length){row.push(cell);rows.push(row);}
  if(!rows.length)return [];
  const h=rows[0].map(x=>x.trim());
  return rows.slice(1).filter(r=>r.some(x=>x!=="")).map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]??""])));
}
function resolve(row){
  for(const c0 of [row["Merchant SKU"],row["FNSKU"],row["ASIN"]]){
    const c=clean(c0); if(!c)continue;
    if(M.woh[c])return M.woh[c];
    const s=M.aliases[c]; if(s&&M.woh[s])return M.woh[s];
  }
  return null;
}
function weight(row,woh){
  const sku=clean(row["Merchant SKU"]), fn=clean(row["FNSKU"]);
  return M.weightsBySku[sku]||M.weightsBySku[woh?.sku]||M.weightsByFnsku[fn]||{};
}
function nearestCase(rec,cap){
  if(rec<=0||cap<=0)return {lower:0,upper:cap||0,nearest:0,variance:rec?1:0};
  const lower=Math.floor(rec/cap)*cap, upper=Math.ceil(rec/cap)*cap;
  const dl=Math.abs(rec-lower), du=Math.abs(upper-rec);
  const nearest=du<=dl?upper:lower;
  return {lower,upper,nearest,variance:Math.abs(nearest-rec)/rec};
}

function closestCaseDivisor(qty,originalCap){
  qty=Math.max(0,Math.round(num(qty))); originalCap=Math.max(1,Math.round(num(originalCap,1)));
  if(qty<=0)return {caseCapacity:originalCap,cases:0};
  let best=1, bestDiff=Math.abs(originalCap-1);
  for(let d=1; d*d<=qty; d++){
    if(qty%d!==0)continue;
    const d2=qty/d;
    for(const cand of [d,d2]){
      const diff=Math.abs(cand-originalCap);
      if(diff<bestDiff || (diff===bestDiff && cand>best)){
        best=cand; bestDiff=diff;
      }
    }
  }
  return {caseCapacity:best,cases:qty/best};
}
function confirmedAssemblySupport(targetSku){
  const comps=M.assemblies[targetSku];
  if(!comps||!comps.length)return {units:0,text:"",components:[]};
  let build=Infinity, details=[];
  for(const c of comps){
    const wr=M.woh[c.sku], inv=wr?num(wr.inventory):0;
    const can=c.qty>0?Math.floor(inv/c.qty):0;
    build=Math.min(build,can); details.push({sku:c.sku,qty:c.qty,inventory:inv,buildable:can});
  }
  if(!Number.isFinite(build))build=0;
  return {units:Math.max(0,build),text:comps.map(c=>`${c.qty}× ${c.sku}`).join(" + "),components:details};
}
function manualReplacementSupport(targetSku,replacementSkus){
  const list=(Array.isArray(replacementSkus)?replacementSkus:[]).filter(Boolean);
  let units=0, details=[];
  const targetPack=packCount(targetSku);
  for(const replacementSku of list){
    const repl=M.woh[replacementSku];
    if(!repl)continue;
    const inv=Math.max(0,Math.floor(num(repl.inventory)));
    const replPack=packCount(replacementSku);
    const targetUnits=Math.floor(inv*replPack/targetPack);
    units += Math.max(0,targetUnits);
    details.push({sku:replacementSku,inventory:inv,targetUnits:Math.max(0,targetUnits)});
  }
  return {units,text:details.map(x=>x.sku).join(" + "),details};
}
function process(rows,rules,replacements={},manualQty={}){
  const out=[];
  for(const a of rows){
    const wr=resolve(a), wt=weight(a,wr);
    const sku=clean(a["Merchant SKU"]), fn=clean(a["FNSKU"]);
    const rec=Math.round(num(a["Recommended replenishment qty"]));
    const dos=num(a["Total Days of Supply (including units from open shipments)"]);
    const cap=Math.round(num(wt.caseCapacity));
    const unitWeight=num(wt.weight);
    const caseWeight=num(wt.caseWeight, unitWeight*cap);
    const direct=wr?Math.max(0,Math.round(num(wr.inventory))):0;
    const loc=wr?.location||"", cls=wr?.amzClass||"";
    const rounding=nearestCase(rec,cap);
    const asm=confirmedAssemblySupport(sku);
    const manualSkus=(replacements[sku]||[]).filter(Boolean);
    const manual=manualSkus.length?manualReplacementSupport(sku,manualSkus):{units:0,text:"",details:[]};
    let related=0, relatedText="";
    if(direct<rounding.nearest){
      if(manualSkus.length){ related=manual.units; relatedText=`Manual: ${manual.text}`; }
      else { related=asm.units; relatedText=asm.text; }
    }
    const supported=direct+related, maxFull=cap>0?Math.floor(supported/cap)*cap:0;
    let finalQty=0, reason="", status="OK";
    if(dos>rules.noReplenishDos){ status="DOS_STOP"; reason=`Do not replenish: ${dos} days of supply exceeds ${rules.noReplenishDos}.`; }
    else if(rec<=0){ reason="Amazon recommended quantity is 0."; }
    else if(cap<=0){ status="MISSING_CASE"; reason="Missing case capacity; manual review required."; }
    else {
      finalQty=Math.min(rounding.nearest,maxFull);
      if(rounding.nearest===0) reason="Nearest full-case quantity is 0.";
      else if(finalQty===0){ status="NO_STOCK"; reason=manualSkus.length?"Selected replacement SKU(s) still cannot support one full case.":"Insufficient direct/related inventory for one full case."; }
      else if(finalQty<rounding.nearest) reason=`Inventory gate reduced ${rounding.nearest} to ${finalQty}.`;
      else if(related>0&&direct<finalQty) reason=`Replacement/assembly inventory supports quantity (${relatedText}).`;
      else reason="Nearest full-case quantity; inventory verified.";
    }
    const varianceFlag=rec>0&&cap>0&&rounding.variance>rules.caseVariance;
    if(varianceFlag&&status==="OK")status="CASE_VARIANCE";

    const hasManualQty=Object.prototype.hasOwnProperty.call(manualQty,sku) && String(manualQty[sku]).trim()!=="";
    const manualFinalQty=hasManualQty?Math.max(0,Math.round(num(manualQty[sku]))):null;
    let effectiveCap=cap, effectiveCaseWeight=caseWeight;
    if(hasManualQty){
      finalQty=manualFinalQty;
      const adjusted=closestCaseDivisor(finalQty,cap||finalQty||1);
      effectiveCap=adjusted.caseCapacity;
      effectiveCaseWeight=unitWeight*effectiveCap;
      status="MANUAL_QTY";
      reason=`Manual final quantity selected: ${manualFinalQty}. Qty per Case adjusted from ${cap||0} to ${effectiveCap} so # Cases stays whole.`;
    }

    const cases=effectiveCap?finalQty/effectiveCap:0;
    const shippingWeight=cases*effectiveCaseWeight;
    const highDos=dos>rules.reviewDos, eee=["E","EE"].includes(String(cls).toUpperCase()), uncomm=/uncommingled/i.test(sku);
    let makeFrom=manualSkus.length?`Manual: ${manualSkus.join(" + ")}`:(asm.text||sku);
    if(!manualSkus.length&&!asm.text&&wr?.altSkus?.length)makeFrom=wr.altSkus.join(" / ");
    out.push({
      country:a["Country"]||"",product:a["Product Name"]||"",fnsku:fn,merchantSku:sku,asin:a["ASIN"]||"",
      amazonRec:rec,totalDos:a["Total Days of Supply (including units from open shipments)"]||"",dos,
      shipDate:a["Recommended ship date"]||"",amazonAction:a["Recommended action"]||"",
      wohSku:wr?.sku||"",amzClass:cls,barcode:wr?.amzBarcode||wr?.barcode||wt.upc||"",
      directInventory:direct,relatedSupport:related,supportedInventory:supported,location:loc,
      originalCaseCapacity:cap,caseCapacity:effectiveCap,caseWeight:effectiveCaseWeight,skuWeight:unitWeight,lowerCase:rounding.lower,upperCase:rounding.upper,nearestCase:rounding.nearest,
      variance:rounding.variance,finalQty,cases,shippingWeight,makeFrom,
      upc:wt.upc||wr?.barcode||"",skuDims:wt.skuDims||"",altBoxDims:wt.altBoxDims||"",caseDims:wt.caseDims||"",
      status,reason,varianceFlag,highDos,eee,uncomm,mapped:!!wr,manualReplacements:manualSkus,manualReplacementDetails:manual.details,
      manualQtyOverride:hasManualQty?manualFinalQty:null,
      confirmedAssembly:asm.components,altSkus:wr?.altSkus||[]
    });
  }
  return out;
}
window.StockLensEngine={parseCSV,process,packCount};
})();
