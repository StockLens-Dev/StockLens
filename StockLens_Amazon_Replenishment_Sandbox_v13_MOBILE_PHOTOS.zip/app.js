
let sourceRows=[],results=[],replacementMap={},manualQtyMap={},pickerTarget=null,pickerSlot=null,replacementMaster={},mobileShip=[],mobileIndex=0,currentRunId="run-none",currentRunName="",photoDb=null,photoDbAvailable=false,volatilePhotos=new Map(),mobilePhotoUrl=null,exportPhotoUrls=[];
const $=id=>document.getElementById(id);
const rules=()=>({caseVariance:Number($("variance").value)/100,reviewDos:Number($("dosReview").value),noReplenishDos:Number($("dosStop").value)});

const REPLACEMENT_MASTER_KEY="stocklensReplacementDecisionMasterV1";
function loadReplacementMaster(){
  try{ replacementMaster=JSON.parse(localStorage.getItem(REPLACEMENT_MASTER_KEY)||"{}")||{}; }
  catch(e){ replacementMaster={}; }
}
function saveReplacementMaster(){ localStorage.setItem(REPLACEMENT_MASTER_KEY,JSON.stringify(replacementMaster)); updateMasterBadge(); }
function updateMasterBadge(){
  const n=Object.keys(replacementMaster).length;
  if($("replacementMasterCount")) $("replacementMasterCount").textContent=`${n} learned replacement mappings`;
}
function applyMasterRecommendations(){
  for(const row of sourceRows){
    const sku=String(row["Merchant SKU"]||"").trim();
    if(!sku || replacementMap[sku]?.length)continue;
    const rec=replacementMaster[sku];
    if(rec&&Array.isArray(rec.replacements)&&rec.replacements.length)replacementMap[sku]=rec.replacements.slice();
  }
}
function learnReplacement(target){
  const reps=(replacementMap[target]||[]).filter(Boolean);
  if(!reps.length)return;
  replacementMaster[target]={
    targetSku:target,
    replacements:reps.slice(),
    updatedAt:new Date().toISOString(),
    source:"sandbox-approved"
  };
  saveReplacementMaster();
}
function unlearnReplacement(target){
  delete replacementMaster[target]; saveReplacementMaster();
}
function exportReplacementMaster(){
  const rows=Object.values(replacementMaster);
  const csv=["Target SKU,Replacement SKUs,Updated At,Source"].concat(rows.map(r=>[
    csvCell(r.targetSku),csvCell((r.replacements||[]).join(" + ")),csvCell(r.updatedAt||""),csvCell(r.source||"")
  ].join(","))).join("\\n");
  const b=new Blob([csv],{type:"text/csv"}),u=URL.createObjectURL(b),a=document.createElement("a");
  a.href=u;a.download="stocklens-replacement-decision-master.csv";a.click();URL.revokeObjectURL(u);
}
function importReplacementMaster(file){
  const rd=new FileReader();
  rd.onload=()=>{
    const rows=StockLensEngine.parseCSV(rd.result);
    for(const r of rows){
      const target=String(r["Target SKU"]||"").trim();
      if(!target)continue;
      const reps=String(r["Replacement SKUs"]||"").split("+").map(x=>x.trim()).filter(x=>window.STOCKLENS_MASTER.woh[x]);
      if(reps.length) replacementMaster[target]={targetSku:target,replacements:reps,updatedAt:r["Updated At"]||new Date().toISOString(),source:r["Source"]||"imported"};
    }
    saveReplacementMaster(); applyMasterRecommendations(); run();
  };
  rd.readAsText(file);
}

function esc(s){return String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}
function hashText(s){
 let h=2166136261;
 for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}
 return (h>>>0).toString(16).padStart(8,"0");
}
function loadText(text,name){
 currentRunId="run-"+hashText(String(name||"")+"|"+text);
 currentRunName=name||"Amazon replenishment";
 sourceRows=StockLensEngine.parseCSV(text);
 $("fileLabel").textContent=`${name}: ${sourceRows.length} rows loaded`;
 applyMasterRecommendations();run();
}
function run(){if(!sourceRows.length)return;results=StockLensEngine.process(sourceRows,rules(),replacementMap,manualQtyMap);render();}
function statusTag(r){if(r.status==="MANUAL_QTY")return '<span class="tag manual">MANUAL QTY</span>';if(r.status==="CASE_VARIANCE")return '<span class="tag warn">&gt;20% REVIEW</span>';if(r.status==="DOS_STOP")return '<span class="tag danger">DOS STOP</span>';if(r.status==="NO_STOCK")return '<span class="tag danger">NO STOCK</span>';if(r.status==="MISSING_CASE")return '<span class="tag warn">NO CASE</span>';return '<span class="tag ok">OK</span>';}
function loadWeightClass(total){
  const warn=Number($("weightWarn").value), limit=Number($("weightLimit").value);
  if(total>=limit)return ["danger","OVER LIMIT"];
  if(total>=warn)return ["warn","CLOSE TO LIMIT"];
  return ["ok","OK"];
}
function render(){
 const ship=results.filter(r=>r.finalQty>0),variance=results.filter(r=>r.varianceFlag),dos=results.filter(r=>r.highDos),
 estock=results.filter(r=>r.eee&&r.directInventory>0),eno=results.filter(r=>r.eee&&r.directInventory<=0),unc=results.filter(r=>r.uncomm),
 unmapped=results.filter(r=>!r.mapped),noStock=results.filter(r=>r.directInventory<=0&&r.amazonRec>0);
 const totalWeight=ship.reduce((a,r)=>a+r.shippingWeight,0), [wc,wt]=loadWeightClass(totalWeight);
 $("kRows").textContent=results.length;$("kShip").textContent=ship.length;$("kUnits").textContent=ship.reduce((a,r)=>a+r.finalQty,0);
 $("kWeight").textContent=totalWeight.toFixed(1)+" lb";$("weightState").className="weightState "+wc;$("weightState").textContent=wt;
 $("kReview").textContent=variance.length+dos.length+estock.length+eno.length+unc.length;
 $("sub").textContent=`${variance.length} case variance · ${noStock.length} no-stock`;
 $("planBody").innerHTML=results.map(r=>`<tr><td>${esc(r.fnsku)}</td><td><b>${esc(r.merchantSku)}</b></td><td>${esc(r.amzClass)}</td><td>${r.amazonRec}</td><td>${r.caseCapacity}</td><td>${r.nearestCase}</td><td>${(r.variance*100).toFixed(1)}%</td><td>${r.directInventory}</td><td>${r.relatedSupport}</td><td><b>${r.finalQty}</b></td><td>${r.cases}</td><td>${r.caseWeight.toFixed(2)}</td><td>${r.shippingWeight.toFixed(2)}</td><td>${statusTag(r)}</td><td class="wrap">${esc(r.reason)}</td></tr>`).join("");
 $("orlandoBody").innerHTML=ship.map(r=>`<tr><td>${esc(r.fnsku)}</td><td>${esc(r.merchantSku)}</td><td class="wrap">${esc(r.makeFrom)}</td><td>${r.directInventory}</td><td>${esc(r.location)}</td><td><b>${r.finalQty}</b></td><td>${r.caseCapacity}</td><td>${r.cases}</td><td>${r.caseWeight.toFixed(2)}</td><td>${r.shippingWeight.toFixed(2)}</td><td>${esc(r.upc)}</td></tr>`).join("");
 renderVariance(variance);
 fillReview("dosBody",dos,r=>[r.merchantSku,r.totalDos,r.amazonRec,r.finalQty,r.reason]);
 fillReview("eStockBody",estock,r=>[r.merchantSku,r.amzClass,r.directInventory,r.finalQty]);
 fillReview("eNoBody",eno,r=>[r.merchantSku,r.amzClass,r.directInventory,r.relatedSupport,r.finalQty]);
 fillReview("uncBody",unc,r=>[r.fnsku,r.merchantSku,r.finalQty]); fillReview("unmappedBody",unmapped,r=>[r.fnsku,r.merchantSku,r.amazonRec]);
 renderNoStock(noStock); renderPdf(ship,totalWeight,wc,wt); renderMobileOrlando(ship); renderPhotoExport();
 $("verify").innerHTML=[
  ["Whole-case errors",results.filter(r=>r.caseCapacity>0&&r.finalQty%r.caseCapacity!==0).length],
  [">DOS stop shipped",results.filter(r=>r.dos>rules().noReplenishDos&&r.finalQty>0).length],
  ["Inventory support errors",results.filter(r=>r.finalQty>r.supportedInventory).length],
  ["Missing case capacity",results.filter(r=>r.caseCapacity<=0&&r.amazonRec>0).length],
  ["Unmapped Amazon rows",unmapped.length]
 ].map(([n,v])=>`<div class="check"><span>${esc(n)}</span><b class="${v===0?"good":"bad"}">${v}</b></div>`).join("");
}
function fillReview(id,arr,fn){$(id).innerHTML=arr.map(r=>"<tr>"+fn(r).map(v=>`<td>${esc(v)}</td>`).join("")+"</tr>").join("");}

function renderVariance(arr){
 $("varianceBody").innerHTML=arr.map(r=>`<tr>
   <td><b>${esc(r.merchantSku)}</b></td><td>${r.amazonRec}</td><td>${r.caseCapacity}</td><td>${r.lowerCase}</td><td>${r.upperCase}</td>
   <td>${r.nearestCase}</td><td>${(r.variance*100).toFixed(1)}%</td>
   <td><input class="manualQtyInput" data-sku="${esc(r.merchantSku)}" type="number" min="0" step="1" value="${manualQtyMap[r.merchantSku]??r.finalQty}" inputmode="numeric"></td>
   <td>${r.finalQty}</td><td class="wrap">${esc(r.reason)}</td>
 </tr>`).join("");
 document.querySelectorAll(".manualQtyInput").forEach(inp=>{
   inp.addEventListener("change",()=>{
     const sku=inp.dataset.sku;
     if(inp.value==="") delete manualQtyMap[sku]; else manualQtyMap[sku]=Math.max(0,Math.round(Number(inp.value)||0));
     run();
   });
 });
}
function renderNoStock(arr){
 $("noStockCount").textContent=arr.length+" items";
 $("noStockBody").innerHTML=arr.map(r=>{
   const selections=(replacementMap[r.merchantSku]||[]);
   const boxes=(selections.length?selections:[""]).map((sku,i)=>replacementBox(r.merchantSku,sku,i)).join("");
   return `<tr><td>${esc(r.fnsku)}</td><td><b>${esc(r.merchantSku)}</b></td><td>${r.amazonRec}</td><td>${r.caseCapacity}</td><td>${r.relatedSupport}</td>
   <td class="replacementCell"><div class="replacementStack">${boxes}</div>
     <div class="replacementActions"><button class="addReplacement" data-target="${esc(r.merchantSku)}" type="button">＋ Add SKU</button>
     <button class="learnReplacement" data-target="${esc(r.merchantSku)}" type="button">Save to Master</button>
     ${replacementMaster[r.merchantSku]?`<button class="unlearnReplacement" data-target="${esc(r.merchantSku)}" type="button">Remove Master</button>`:""}</div>
     ${replacementMaster[r.merchantSku]?`<div class="masterHint">Auto recommendation saved: ${esc((replacementMaster[r.merchantSku].replacements||[]).join(" + "))}</div>`:""}
   </td>
   <td class="wrap">${(r.manualReplacementDetails||[]).map(x=>`${esc(x.sku)}: inv ${x.inventory} → ${x.targetUnits} target units`).join("<br>")||"—"}</td>
   <td><b>${r.finalQty}</b></td><td class="wrap">${esc(r.makeFrom)}</td></tr>`;
 }).join("");
 document.querySelectorAll(".pickReplacement").forEach(btn=>btn.addEventListener("click",()=>openPicker(btn.dataset.target,Number(btn.dataset.slot))));
 document.querySelectorAll(".removeReplacement").forEach(btn=>btn.addEventListener("click",()=>{
   const target=btn.dataset.target, slot=Number(btn.dataset.slot), list=(replacementMap[target]||[]).slice();
   list.splice(slot,1); if(list.filter(Boolean).length)replacementMap[target]=list.filter(Boolean); else delete replacementMap[target]; run();
 }));
 document.querySelectorAll(".addReplacement").forEach(btn=>btn.addEventListener("click",()=>{
   const target=btn.dataset.target, list=(replacementMap[target]||[]).slice(); list.push(""); replacementMap[target]=list; renderNoStock(results.filter(r=>r.directInventory<=0&&r.amazonRec>0));
 }));
 document.querySelectorAll(".learnReplacement").forEach(btn=>btn.addEventListener("click",()=>{learnReplacement(btn.dataset.target);renderNoStock(results.filter(r=>r.directInventory<=0&&r.amazonRec>0));}));
 document.querySelectorAll(".unlearnReplacement").forEach(btn=>btn.addEventListener("click",()=>{unlearnReplacement(btn.dataset.target);renderNoStock(results.filter(r=>r.directInventory<=0&&r.amazonRec>0));}));

}
function replacementBox(target,sku,slot){
 const wr=sku?window.STOCKLENS_MASTER.woh[sku]:null;
 return `<div class="replacementBox">
   <button type="button" class="pickReplacement" data-target="${esc(target)}" data-slot="${slot}">
     <span class="pickMain">${sku?esc(sku):"Choose replacement SKU"}</span>
     <span class="pickSub">${wr?`Inv ${wr.inventory} · ${esc(wr.description||"")}`:"Tap to search inventory"}</span>
   </button>
   ${sku?`<button type="button" class="removeReplacement" aria-label="Remove" data-target="${esc(target)}" data-slot="${slot}">×</button>`:""}
 </div>`;
}
function openPicker(target,slot){
 pickerTarget=target; pickerSlot=slot; $("pickerSearch").value=""; $("skuPickerModal").classList.add("open"); renderPicker("");
 setTimeout(()=>$("pickerSearch").focus(),50);
}
function closePicker(){ $("skuPickerModal").classList.remove("open"); pickerTarget=null; pickerSlot=null; }
function renderPicker(q){
 q=String(q||"").trim().toLowerCase();
 const items=window.STOCKLENS_MASTER.replacementCatalog.filter(x=>!q || x.sku.toLowerCase().includes(q) || String(x.description||"").toLowerCase().includes(q)).slice(0,120);
 $("pickerResults").innerHTML=items.map(x=>`<button type="button" class="pickerItem" data-sku="${esc(x.sku)}">
   <span><b>${esc(x.sku)}</b><small>${esc(x.description||"")}</small></span><strong>Inv ${x.inventory}</strong>
 </button>`).join("") || '<div class="emptyPicker">No matching SKU</div>';
 document.querySelectorAll(".pickerItem").forEach(btn=>btn.addEventListener("click",()=>{
   const list=(replacementMap[pickerTarget]||[]).slice();
   while(list.length<=pickerSlot)list.push("");
   list[pickerSlot]=btn.dataset.sku; replacementMap[pickerTarget]=list.filter((x,i)=>x || i===pickerSlot);
   closePicker(); run();
 }));
}
function barcodeSvg(value){
 value=String(value||"").replace(/\D/g,"");
 if(!value)return '<div class="barcodeMissing">NO NUMERIC BARCODE</div>';
 if(value.length===11) value = value + upcCheckDigit(value);
 if(value.length===12) return renderUPCA(value);
 if(value.length===13) return renderEAN13(value);
 return `<div class="barcodeMissing">BARCODE NOT EAN/UPC<br>${esc(value)}</div>`;
}
function upcCheckDigit(s){
 let sum=0;
 for(let i=0;i<11;i++){ const d=Number(s[i]); sum += (i%2===0?3:1)*d; }
 return String((10-(sum%10))%10);
}
function ean13CheckDigit(s){
 let sum=0;
 for(let i=0;i<12;i++){ const d=Number(s[i]); sum += (i%2===0?1:3)*d; }
 return String((10-(sum%10))%10);
}
function renderUPCA(value){
 const L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
 const R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
 if(value.length!==12 || !/^\d{12}$/.test(value)) return `<div class="barcodeMissing">INVALID UPC-A<br>${esc(value)}</div>`;
 const chk = upcCheckDigit(value.slice(0,11));
 const full = value.slice(0,11) + chk;
 const left = full.slice(0,6), right = full.slice(6);
 let bits = "101";
 for(const ch of left) bits += L[Number(ch)];
 bits += "01010";
 for(const ch of right) bits += R[Number(ch)];
 bits += "101";
 return drawBarcode(bits, full, {
   kind:"UPC-A",
   leftText:[full.slice(0,1), full.slice(1,6)],
   rightText:[full.slice(6,11), full.slice(11)]
 });
}
function renderEAN13(value){
 const L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
 const G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"];
 const R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
 const PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];
 if(value.length===12) value = value + ean13CheckDigit(value);
 if(value.length!==13 || !/^\d{13}$/.test(value)) return `<div class="barcodeMissing">INVALID EAN-13<br>${esc(value)}</div>`;
 const first = Number(value[0]), left = value.slice(1,7), right = value.slice(7), parity = PAR[first];
 let bits = "101";
 for(let i=0;i<6;i++){
   const d = Number(left[i]);
   bits += parity[i] === "L" ? L[d] : G[d];
 }
 bits += "01010";
 for(const ch of right) bits += R[Number(ch)];
 bits += "101";
 return drawBarcode(bits, value, {
   kind:"EAN-13",
   leftText:[value.slice(0,1), value.slice(1,7)],
   rightText:[value.slice(7,13)]
 });
}
function drawBarcode(bits, label, opts){
 const module = 1.75, quiet = 11 * module, normalH = 46, guardH = 52;
 let x = quiet, bars = "";
 const startGuard = [0,1,2], centerGuard = [45,46,47,48,49], endGuard = [92,93,94];
 const guards = new Set([...startGuard, ...centerGuard, ...endGuard]);
 for(let i=0;i<bits.length;i++){
   if(bits[i] === "1"){
     const h = guards.has(i) ? guardH : normalH;
     const y = guards.has(i) ? 0 : 6;
     bars += `<rect x="${x.toFixed(2)}" y="${y}" width="${module}" height="${h}"/>`;
   }
   x += module;
 }
 const totalW = x + quiet, textY = 64;
 let text = "";
 if(opts.kind === "UPC-A"){
   text += `<text x="${(quiet-7).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.leftText[0])}</text>`;
   text += `<text x="${(quiet + module*24).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.leftText[1])}</text>`;
   text += `<text x="${(quiet + module*71).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.rightText[0])}</text>`;
   text += `<text x="${(quiet + module*101 + 7).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.rightText[1])}</text>`;
 } else {
   text += `<text x="${(quiet-7).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.leftText[0])}</text>`;
   text += `<text x="${(quiet + module*24).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.leftText[1])}</text>`;
   text += `<text x="${(quiet + module*71).toFixed(2)}" y="${textY}" text-anchor="middle" font-size="10">${esc(opts.rightText[0])}</text>`;
 }
 return `<svg class="barcodeSvg ean" viewBox="0 0 ${totalW.toFixed(2)} 68" preserveAspectRatio="xMidYMid meet" aria-label="${esc(opts.kind)} ${esc(label)}"><rect x="0" y="0" width="${totalW.toFixed(2)}" height="68" fill="#fff"/><g fill="#000" shape-rendering="crispEdges">${bars}</g>${text}</svg>`;
}


function renderPdf(ship,totalWeight,wc,wt){
 const pageSize=7;
 const pages=[];
 for(let i=0;i<ship.length;i+=pageSize) pages.push(ship.slice(i,i+pageSize));
 $("pdfWeight").className="weightBanner "+wc;
 $("pdfWeight").textContent=`Shipping weight: ${totalWeight.toFixed(1)} lb · ${wt}`;
 $("pdfPages").innerHTML=pages.map((page,pidx)=>`
   <div class="orlandoPage">
     <table class="orlandoPdfTable">
       <colgroup>
         <col class="cFn"><col class="cSku"><col class="cBarcode"><col class="cMake">
         <col class="cInv"><col class="cLoc"><col class="cQty"><col class="cCase">
         <col class="cCases"><col class="cUpc"><col class="cNote">
       </colgroup>
       <thead><tr>
         <th class="yellow">FNSKU</th>
         <th class="yellow">Merchant SKU</th>
         <th>Barcode</th>
         <th>Make from SKU</th>
         <th>Inv<br>Hallandale</th>
         <th>Location</th>
         <th class="yellow">qty</th>
         <th>Qty per<br>Case</th>
         <th># Cases</th>
         <th>UPC</th>
         <th class="yellow noteHead">Anotar Ultimos 4 del UPC<br>que se uso y sticker si<br>aplica</th>
       </tr></thead>
       <tbody>
       ${page.map(r=>`
         <tr>
           <td class="fnskuCell">${esc(r.fnsku)}</td>
           <td class="merchantCell">${esc(r.merchantSku)}</td>
           <td class="barcodeCell">${barcodeSvg(r.barcode||r.upc||"")}</td>
           <td class="makeCell" title="${esc(r.makeFrom)}">${esc(String(r.makeFrom||"").replace(/^Manual:\\s*/i,""))}</td>
           <td class="numCell">${r.directInventory}</td>
           <td class="locationCell">${esc(r.location)}</td>
           <td class="qtyCell">${r.finalQty}</td>
           <td class="caseCell">${r.caseCapacity}</td>
           <td class="casesCell">${Number(r.cases).toFixed(2)}</td>
           <td class="upcCell">${esc(r.upc)}</td>
           <td class="noteCell"></td>
         </tr>`).join("")}
       </tbody>
     </table>
   </div>`).join("");
}


/* ---------- Orlando mobile cards + line photo storage ---------- */
function linePhotoId(r){return `${currentRunId}::${r.fnsku||""}::${r.merchantSku||""}`;}

function initPhotoDb(){
 return new Promise(resolve=>{
   if(!("indexedDB" in window)){
     photoDbAvailable=false; updatePhotoStorageStatus(); resolve(false); return;
   }
   try{
     const req=indexedDB.open("StockLensOrlandoPhotos",1);
     req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains("photos"))db.createObjectStore("photos",{keyPath:"id"});};
     req.onsuccess=()=>{photoDb=req.result;photoDbAvailable=true;updatePhotoStorageStatus();resolve(true);};
     req.onerror=()=>{photoDbAvailable=false;updatePhotoStorageStatus();resolve(false);};
   }catch(e){photoDbAvailable=false;updatePhotoStorageStatus();resolve(false);}
 });
}
function updatePhotoStorageStatus(){
 const el=$("photoStorageStatus"); if(!el)return;
 if(photoDbAvailable){
   el.className="photoStorageStatus ok";
   el.textContent="Photos are saved in this browser/device for each replenishment run. They are not yet synced to Google Drive or other devices.";
 }else{
   el.className="photoStorageStatus warn";
   el.textContent="Permanent browser photo storage is unavailable here. Photos will work for this open session only; use a normal hosted/localhost version for reliable saving.";
 }
}
function photoPut(rec){
 volatilePhotos.set(rec.id,rec);
 if(!photoDbAvailable||!photoDb)return Promise.resolve();
 return new Promise((resolve,reject)=>{
   const tx=photoDb.transaction("photos","readwrite");
   tx.objectStore("photos").put(rec);
   tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error);
 });
}
function photoGet(id){
 if(volatilePhotos.has(id))return Promise.resolve(volatilePhotos.get(id));
 if(!photoDbAvailable||!photoDb)return Promise.resolve(null);
 return new Promise(resolve=>{
   const tx=photoDb.transaction("photos","readonly"),req=tx.objectStore("photos").get(id);
   req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>resolve(null);
 });
}
function photoDelete(id){
 volatilePhotos.delete(id);
 if(!photoDbAvailable||!photoDb)return Promise.resolve();
 return new Promise(resolve=>{
   const tx=photoDb.transaction("photos","readwrite");tx.objectStore("photos").delete(id);
   tx.oncomplete=()=>resolve();tx.onerror=()=>resolve();
 });
}
function blobToDataUrl(blob){return new Promise((resolve,reject)=>{const rd=new FileReader();rd.onload=()=>resolve(rd.result);rd.onerror=reject;rd.readAsDataURL(blob);});}
async function compressPhoto(file){
 try{
   const src=URL.createObjectURL(file);
   const img=new Image();
   await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=src;});
   const max=1600,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));
   const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale));
   const c=document.createElement("canvas");c.width=w;c.height=h;
   c.getContext("2d").drawImage(img,0,0,w,h);URL.revokeObjectURL(src);
   return await new Promise(resolve=>c.toBlob(b=>resolve(b||file),"image/jpeg",0.84));
 }catch(e){return file;}
}
function renderMobileOrlando(ship){
 const oldKey=mobileShip[mobileIndex]?linePhotoId(mobileShip[mobileIndex]):null;
 mobileShip=ship.slice();
 if(oldKey){
   const found=mobileShip.findIndex(r=>linePhotoId(r)===oldKey);
   if(found>=0)mobileIndex=found;
 }
 if(mobileIndex>=mobileShip.length)mobileIndex=Math.max(0,mobileShip.length-1);
 if($("mobileRunName"))$("mobileRunName").textContent=currentRunName||"Current Orlando shipment";
 if($("mobileEmpty"))$("mobileEmpty").hidden=mobileShip.length>0;
 if($("mobileCardShell"))$("mobileCardShell").hidden=mobileShip.length===0;
 if($("mobileBottomNav"))$("mobileBottomNav").hidden=mobileShip.length===0;
 renderMobileCard();
 updateMobilePhotoCount();
}
async function renderMobileCard(){
 if(!$("mobileCard"))return;
 if(!mobileShip.length){
   $("mobileCard").innerHTML="";
   $("mobileCardProgress").textContent="0 / 0";
   return;
 }
 const r=mobileShip[mobileIndex];
 $("mobileCardProgress").textContent=`${mobileIndex+1} / ${mobileShip.length}`;
 $("mobilePrev").disabled=$("mobilePrevBottom").disabled=mobileIndex===0;
 $("mobileNext").disabled=$("mobileNextBottom").disabled=mobileIndex===mobileShip.length-1;
 const make=String(r.makeFrom||"").replace(/^Manual:\s*/i,"");
 $("mobileCard").innerHTML=`
   <div class="mobileCardHeader">
     <div class="mobileSku">${esc(r.merchantSku)}</div>
     <div class="mobileFnsku">FNSKU: ${esc(r.fnsku)}</div>
   </div>
   <div class="mobileCardBody">
     <div class="mobileBarcode">${barcodeSvg(r.upc||r.barcode||"")}</div>
     <div class="mobileFields">
       <div class="mobileField full"><div class="label">Make from SKU</div><div class="value">${esc(make||r.merchantSku)}</div></div>
       <div class="mobileField"><div class="label">Inv Hallandale</div><div class="value">${r.directInventory}</div></div>
       <div class="mobileField"><div class="label">Location</div><div class="value">${esc(r.location||"—")}</div></div>
       <div class="mobileField qty"><div class="label">Qty</div><div class="value">${r.finalQty}</div></div>
       <div class="mobileField"><div class="label">Qty per Case</div><div class="value">${r.caseCapacity}</div></div>
       <div class="mobileField"><div class="label"># Cases</div><div class="value">${Number(r.cases).toFixed(2)}</div></div>
       <div class="mobileField"><div class="label">UPC</div><div class="value">${esc(r.upc||"—")}</div></div>
     </div>
     <div class="mobilePhotoArea">
       <div id="mobilePhotoPreview" class="mobilePhotoPreview">No picture saved for this line yet.</div>
       <div class="mobilePhotoActions">
         <button id="takeLinePhoto" class="cameraBtn" type="button">📷 Take / Retake Picture</button>
         <button id="removeLinePhoto" class="removePhotoBtn" type="button" hidden>Remove Picture</button>
       </div>
       <div id="mobilePhotoSaved" class="mobilePhotoSaved"></div>
     </div>
   </div>`;
 $("takeLinePhoto").onclick=()=>{const input=$("orlandoCameraInput");input.value="";input.click();};
 $("removeLinePhoto").onclick=async()=>{await photoDelete(linePhotoId(r));await renderMobileCard();await renderPhotoExport();await updateMobilePhotoCount();};
 const rec=await photoGet(linePhotoId(r));
 if(mobilePhotoUrl){URL.revokeObjectURL(mobilePhotoUrl);mobilePhotoUrl=null;}
 if(rec&&rec.blob){
   mobilePhotoUrl=URL.createObjectURL(rec.blob);
   $("mobilePhotoPreview").innerHTML=`<img src="${mobilePhotoUrl}" alt="Photo for ${esc(r.merchantSku)}">`;
   $("removeLinePhoto").hidden=false;
   $("mobilePhotoSaved").textContent=`Saved ${new Date(rec.capturedAt).toLocaleString()}`;
 }
}
function mobileMove(delta){
 if(!mobileShip.length)return;
 const next=Math.max(0,Math.min(mobileShip.length-1,mobileIndex+delta));
 if(next===mobileIndex)return;
 mobileIndex=next;renderMobileCard();
}
async function saveCameraPhoto(file){
 if(!file||!mobileShip.length)return;
 const r=mobileShip[mobileIndex],blob=await compressPhoto(file);
 await photoPut({
   id:linePhotoId(r),runId:currentRunId,runName:currentRunName,
   merchantSku:r.merchantSku,fnsku:r.fnsku,upc:r.upc||"",qty:r.finalQty,
   capturedAt:new Date().toISOString(),blob
 });
 await renderMobileCard();await renderPhotoExport();await updateMobilePhotoCount();
}
async function updateMobilePhotoCount(){
 let count=0;
 for(const r of mobileShip){if(await photoGet(linePhotoId(r)))count++;}
 if($("mobilePhotoCount"))$("mobilePhotoCount").textContent=`${count} photo${count===1?"":"s"} / ${mobileShip.length}`;
}
function clearExportPhotoUrls(){for(const u of exportPhotoUrls)URL.revokeObjectURL(u);exportPhotoUrls=[];}
async function renderPhotoExport(){
 const grid=$("photoExportGrid"); if(!grid)return;
 const ship=mobileShip;
 $("photoExportCount").textContent=`${ship.length} line${ship.length===1?"":"s"}`;
 clearExportPhotoUrls();
 if(!ship.length){grid.innerHTML='<div class="mobileEmpty">No current Orlando shipment lines.</div>';return;}
 let html="";
 for(const r of ship){
   const rec=await photoGet(linePhotoId(r));
   let photo='<div class="photoExportPhoto">No picture saved</div>',stamp='<div class="photoExportStamp photoMissingStamp">Photo missing</div>';
   if(rec&&rec.blob){
     const u=URL.createObjectURL(rec.blob);exportPhotoUrls.push(u);
     photo=`<div class="photoExportPhoto"><img src="${u}" alt="Photo for ${esc(r.merchantSku)}"></div>`;
     stamp=`<div class="photoExportStamp">Photo saved ${new Date(rec.capturedAt).toLocaleString()}</div>`;
   }
   html+=`<article class="photoExportCard">
     ${photo}
     <div class="photoExportInfo">
       <div class="photoExportSku">${esc(r.merchantSku)}</div>
       <div class="photoExportFn">FNSKU: ${esc(r.fnsku)}</div>
       <div class="photoExportMeta"><span><b>Qty</b><br>${r.finalQty}</span><span><b># Cases</b><br>${Number(r.cases).toFixed(2)}</span><span><b>Location</b><br>${esc(r.location||"—")}</span><span><b>UPC</b><br>${esc(r.upc||"—")}</span></div>
       ${stamp}
     </div>
   </article>`;
 }
 grid.innerHTML=html;
}
async function printPhotoExport(){
 if(!mobileShip.length)return;
 let cards="";
 for(const r of mobileShip){
   const rec=await photoGet(linePhotoId(r));
   let image='<div class="photoExportPhoto">No picture saved</div>';
   if(rec&&rec.blob){const data=await blobToDataUrl(rec.blob);image=`<div class="photoExportPhoto"><img src="${data}"></div>`;}
   cards+=`<article class="photoExportCard">${image}<div class="photoExportInfo"><div class="photoExportSku">${esc(r.merchantSku)}</div><div class="photoExportFn">FNSKU: ${esc(r.fnsku)}</div><div class="photoExportMeta"><span><b>Qty</b><br>${r.finalQty}</span><span><b># Cases</b><br>${Number(r.cases).toFixed(2)}</span><span><b>Location</b><br>${esc(r.location||"—")}</span><span><b>UPC</b><br>${esc(r.upc||"—")}</span></div></div></article>`;
 }
 const w=window.open("","_blank");
 w.document.write(`<html><head><title>Orlando Photo Report - ${esc(currentRunName)}</title><style>
 body{font-family:Arial,sans-serif;margin:.25in;color:#111}h1{font-size:20px;margin:0 0 5px}p{font-size:11px;color:#555;margin:0 0 14px}
 .photoExportGrid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.photoExportCard{border:1px solid #111;break-inside:avoid;overflow:hidden}
 .photoExportPhoto{height:3.1in;background:#eee;display:flex;align-items:center;justify-content:center;font-size:13px}.photoExportPhoto img{width:100%;height:100%;object-fit:contain;background:#111}
 .photoExportInfo{padding:10px}.photoExportSku{font-weight:800;font-size:16px}.photoExportFn{font-size:11px;margin-top:3px}
 .photoExportMeta{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;font-size:10px;margin-top:8px}.photoExportMeta span{border:1px solid #ddd;padding:5px}
 @page{size:letter portrait;margin:.25in}
 </style></head><body><h1>Orlando Photo Report</h1><p>${esc(currentRunName)} · ${new Date().toLocaleString()}</p><div class="photoExportGrid">${cards}</div></body></html>`);
 w.document.close();setTimeout(()=>w.print(),450);
}
function exportPhotoManifest(){
 const rows=[["Merchant SKU","FNSKU","Qty","# Cases","Location","UPC","Photo Saved","Run"]];
 (async()=>{
   for(const r of mobileShip){
     const rec=await photoGet(linePhotoId(r));
     rows.push([r.merchantSku,r.fnsku,r.finalQty,Number(r.cases).toFixed(2),r.location||"",r.upc||"",rec?"Yes":"No",currentRunName]);
   }
   const text=rows.map(row=>row.map(csvCell).join(",")).join("\n");
   const b=new Blob([text],{type:"text/csv"}),u=URL.createObjectURL(b),a=document.createElement("a");
   a.href=u;a.download="stocklens-orlando-photo-manifest.csv";a.click();URL.revokeObjectURL(u);
 })();
}

function csvCell(v){let s=String(v??"");return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
function exportCSV(kind){
 const arr=kind==="orlando"?results.filter(r=>r.finalQty>0):results;
 const cols=kind==="orlando"?
 [["FNSKU","fnsku"],["Merchant SKU","merchantSku"],["Barcode","barcode"],["Make from SKU","makeFrom"],["Inv Hallandale","directInventory"],["Related Support","relatedSupport"],["Location","location"],["qty","finalQty"],["Qty per Case","caseCapacity"],["# Cases","cases"],["Case Weight","caseWeight"],["Ship Weight","shippingWeight"],["UPC","upc"],["comment","reason"]]:
 [["FNSKU","fnsku"],["Merchant SKU","merchantSku"],["AMZ Class","amzClass"],["Amazon Request","amazonRec"],["Case Capacity","caseCapacity"],["Nearest Case","nearestCase"],["Variance %","variance"],["Direct Inventory","directInventory"],["Related Support","relatedSupport"],["Final Qty","finalQty"],["# Cases","cases"],["Case Weight","caseWeight"],["Ship Weight","shippingWeight"],["Status","status"],["Reason","reason"]];
 const text=[cols.map(x=>csvCell(x[0])).join(",")].concat(arr.map(r=>cols.map(([h,k])=>csvCell(k==="variance"?(r[k]*100).toFixed(1):r[k])).join(","))).join("\n");
 const b=new Blob([text],{type:"text/csv"}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=`stocklens-${kind}.csv`;a.click();URL.revokeObjectURL(u);
}
function printPdf(){
 const el=$("pdfPaper").outerHTML, css=document.querySelector("style").innerHTML;
 const w=window.open("","_blank"); w.document.write(`<html><head><title>Orlando List</title><style>${css}@media print{body{background:white}.pdfPaper{box-shadow:none;margin:0;width:100%;max-width:none}.noPrint{display:none}}</style></head><body>${el}</body></html>`); w.document.close(); setTimeout(()=>w.print(),300);
}
document.addEventListener("DOMContentLoaded",()=>{
 initPhotoDb().then(()=>{renderMobileCard();renderPhotoExport();});
 loadReplacementMaster(); updateMasterBadge();
 $("exportReplacementMaster").addEventListener("click",exportReplacementMaster);
 $("importReplacementMaster").addEventListener("change",e=>{const f=e.target.files[0];if(f)importReplacementMaster(f);e.target.value="";});

 $("file").addEventListener("change",e=>{let f=e.target.files[0];if(!f)return;let rd=new FileReader();rd.onload=()=>loadText(rd.result,f.name);rd.readAsText(f);});
 $("sample").onclick=()=>loadText(window.STOCKLENS_SAMPLE_CSV,"Sample 2026-06-15");$("run").onclick=run;$("expPlan").onclick=()=>exportCSV("plan");$("expOrlando").onclick=()=>exportCSV("orlando");$("printPdf").onclick=printPdf;
 $("mobilePrev").onclick=$("mobilePrevBottom").onclick=()=>mobileMove(-1);
 $("mobileNext").onclick=$("mobileNextBottom").onclick=()=>mobileMove(1);
 $("orlandoCameraInput").addEventListener("change",e=>{const f=e.target.files&&e.target.files[0];if(f)saveCameraPhoto(f);});
 $("refreshPhotoExport").onclick=renderPhotoExport;
 $("printPhotoExport").onclick=printPhotoExport;
 $("exportPhotoManifest").onclick=exportPhotoManifest;
 let swipeStartX=null;
 $("mobileCardShell").addEventListener("touchstart",e=>{swipeStartX=e.changedTouches[0].clientX;},{passive:true});
 $("mobileCardShell").addEventListener("touchend",e=>{if(swipeStartX===null)return;const dx=e.changedTouches[0].clientX-swipeStartX;swipeStartX=null;if(Math.abs(dx)>55)mobileMove(dx<0?1:-1);},{passive:true});
 ["variance","dosReview","dosStop","weightWarn","weightLimit"].forEach(id=>$(id).addEventListener("change",run));
 document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{document.querySelectorAll("[data-tab]").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.tab).classList.add("active");});
 $("pickerSearch").addEventListener("input",e=>renderPicker(e.target.value));
 $("pickerClose").addEventListener("click",closePicker);
 $("skuPickerModal").addEventListener("click",e=>{if(e.target===$("skuPickerModal"))closePicker();});
 const c=window.STOCKLENS_MASTER.meta.counts;$("masterCounts").textContent=`${c.woh} WOH SKUs · ${c.weights} weight rows · ${c.assemblies} assembly mappings · ${c.aliases} aliases`;
 loadText(window.STOCKLENS_SAMPLE_CSV,"Sample 2026-06-15");
});
