# StockLens Amazon Replenishment Sandbox v3

New in v3:
- Orlando PDF Preview in the left navigation.
- Machine-readable Code 128-style barcode rendering in the live preview.
- Print / Save as PDF from the browser.
- No Stock Replacements screen with searchable replacement SKU selectors.
- Selected replacement SKU is written into Make from SKU for Orlando CSV/PDF output.
- Replacement stock is converted to target-SKU equivalents using pack prefixes such as 2x and 4x.
- Case weight calculated from item weight × case capacity in the embedded weight snapshot.
- Shipping weight = # cases × case weight.
- Default warning threshold: 1,350 lb; hard limit: 1,500 lb. Both can be changed in the UI.
- All master data remains an embedded read-only snapshot; no master files are modified.

Open index.html in a browser.

- Barcode rendering updated to scanner-readable UPC-A (12-digit) and EAN-13 (13-digit) output in the Orlando PDF preview.

- Case Variance Review now includes a manual Final Qty field. The chosen quantity becomes the applied quantity throughout the sandbox.
- No Stock Replacements now uses an in-site mobile-friendly searchable modal instead of a browser datalist.
- Each no-stock item supports multiple replacement SKU lines via + Add SKU.
- Multiple replacement selections are carried into Make from SKU on Orlando output/export.

- Manual Case Variance quantities now auto-adjust the effective Qty per Case to the closest divisor of the selected quantity, keeping # Cases whole.
- Added a separate Replacement Decision Master.
- Clicking Save to Master stores the target SKU and one or more chosen replacement SKUs in browser local storage.
- Future runs automatically prefill learned replacement recommendations.
- Replacement Decision Master can be exported/imported as CSV for portability.
- The replacement master remains separate from WOH, inventory, weight, location, and other StockLens masters.

- Orlando PDF Preview reformatted to match the supplied Orlando list reference:
  FNSKU, Merchant SKU, Barcode, Make from SKU, Inv Hallandale, Location, qty,
  Qty per Case, # Cases, UPC, and the yellow notes column.
- Uses yellow headers on FNSKU, Merchant SKU, qty, and the notes column.
- Uses black gridlines, bold merchant SKU/qty/cases, landscape letter pages, and 11 rows per page.
- Shipping-weight monitor remains in the app toolbar but is omitted from the printed Orlando table to preserve the reference layout.

- Orlando print layout refined:
  - Make from SKU stays on one line by default and removes the visual "Manual:" prefix in the printed list.
  - Page margins increased so the grid is not pressed against paper edges.
  - Printed font sizes increased for readability.
  - Rows per page reduced from 11 to 9.
  - UPC-A / EAN-13 SVGs now preserve aspect ratio instead of being horizontally stretched.
  - Barcode bars use crisp-edge rendering and more white space around the symbol for improved scan reliability.

- v10 print changes:
  - Orlando rows per page reduced from 9 to 7.
  - Barcode column widened and barcode symbols enlarged to about 1.6 inches wide in preview / 1.52 inches in print.
  - Barcode module width increased while preserving aspect ratio.
  - Orlando PDF font sizes increased again throughout the table.
  - Quantity text increased to 16px-equivalent print styling for quick visual checking.

- v11 Orlando formatting:
  - Make from SKU now wraps naturally to a second line instead of truncating with ellipsis.
  - Make from SKU font increased.
  - Inv Hallandale, Location, qty, Qty per Case, and # Cases font sizes increased.
  - Column widths rebalanced to preserve page fit while allowing cleaner Make from SKU wrapping.

- v12: WOH snapshot refreshed from current Google Drive WOH.xlsm (modified 2026-09-30). Live Drive file was read-only and not modified.

- v13 adds Orlando Mobile Cards:
  - Each current Orlando shipment line is shown as a large mobile card.
  - Previous/Next arrows and swipe gestures move between lines.
  - Each card shows barcode, Make from SKU, inventory, location, qty, Qty per Case, # Cases, and UPC.
  - A Take / Retake Picture button opens the phone camera/file capture picker.
  - The saved picture is attached to that specific replenishment run + FNSKU + Merchant SKU line.
- Added Photo Export category:
  - Shows every current Orlando shipment line with its respective saved picture or a Photo missing placeholder.
  - Print / Save Photo Report creates a printable report with SKU details and pictures.
  - Photo Manifest CSV records which shipment lines have pictures.
- Photo storage uses IndexedDB when available, with in-memory fallback.
  - Photos are local to the current browser/device and are not yet synced to Drive/cloud storage.
